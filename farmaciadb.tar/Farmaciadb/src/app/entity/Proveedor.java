package app.entity;

public class Proveedor {
    private String nombre, correo, direccion, tipo, horario, sitoWeb, personaContacto;
    private int telefono;
    private Cuenta cuenta;

    public Proveedor(String nombre, String correo, String direccion, String tipo, String horario, String sitoWeb, String personaContacto, int telefono, Cuenta cuenta) {
        this.nombre = nombre;
        this.correo = correo;
        this.direccion = direccion;
        this.tipo = tipo;
        this.horario = horario;
        this.sitoWeb = sitoWeb;
        this.personaContacto = personaContacto;
        this.telefono = telefono;
        this.cuenta = cuenta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getSitoWeb() {
        return sitoWeb;
    }

    public void setSitoWeb(String sitoWeb) {
        this.sitoWeb = sitoWeb;
    }

    public String getPersonaContacto() {
        return personaContacto;
    }

    public void setPersonaContacto(String personaContacto) {
        this.personaContacto = personaContacto;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }
    
    
}
